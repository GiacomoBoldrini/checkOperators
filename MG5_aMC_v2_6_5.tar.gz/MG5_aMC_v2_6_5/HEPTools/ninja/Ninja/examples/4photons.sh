#! /bin/sh

ninjanumgen 4photons.frm --nlegs 4 --rank 4 --diagname FourPhotons \
    -o 4photons_num.cc
