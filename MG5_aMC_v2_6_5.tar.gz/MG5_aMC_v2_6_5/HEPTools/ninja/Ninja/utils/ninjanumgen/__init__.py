from ninjanumgen import *
