/* src/ninja/ninja_config.h.  Generated from ninja_config.h.in by configure.  */

/* Define to 1 if ninja is compiled in quadruple precision. */
#ifndef QUADNINJA_QUADRUPLE
/* #undef QUADNINJA_QUADRUPLE */
#endif

/* Define if you have LoopTools. */
#ifndef QUADNINJA_USE_LOOPTOOLS
/* #undef QUADNINJA_USE_LOOPTOOLS */
#endif

/* Define if you have OneLoop. */
#ifndef QUADNINJA_USE_ONELOOP
#define QUADNINJA_USE_ONELOOP 1
#endif

/* Define to 1 if quadninja is compiled. */
#ifndef QUADNINJA
#define QUADNINJA 1
#endif
/* src/ninja/ninja_config.h.  Generated from ninja_config.h.in by configure.  */

/* Define to 1 if ninja is compiled in quadruple precision. */
#ifndef NINJA_QUADRUPLE
/* #undef NINJA_QUADRUPLE */
#endif

/* Define if you have LoopTools. */
#ifndef NINJA_USE_LOOPTOOLS
/* #undef NINJA_USE_LOOPTOOLS */
#endif

/* Define if you have OneLoop. */
#ifndef NINJA_USE_ONELOOP
#define NINJA_USE_ONELOOP 1
#endif

/* Define to 1 if quadninja is compiled. */
#ifndef QUADNINJA
#define QUADNINJA 1
#endif

#undef QUADNINJA_USE_LOOPTOOLS
